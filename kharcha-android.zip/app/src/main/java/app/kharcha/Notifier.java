package app.kharcha;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;

import java.text.NumberFormat;
import java.util.Locale;

final class Notifier {
    static final String CHANNEL = "saved";

    private Notifier() {}

    static int notifId(String id) {
        return id.hashCode() & 0x7fffffff;
    }

    private static NotificationManager manager(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Saved expenses", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("A bank SMS was saved to Kharcha");
            nm.createNotificationChannel(ch);
        }
        return nm;
    }

    static String rupees(double v) {
        NumberFormat f = NumberFormat.getNumberInstance(new Locale("en", "IN"));
        f.setMaximumFractionDigits(v == Math.floor(v) ? 0 : 2);
        return "₹" + f.format(v);
    }

    static void saved(Context c, String id, double amount, String merchant, boolean possibleDup) {
        NotificationManager nm = manager(c);
        String what = merchant == null || merchant.isEmpty() ? "bank debit" : merchant;

        Intent open = new Intent(c, MainActivity.class)
                .putExtra("edit", id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pOpen = PendingIntent.getActivity(c, notifId(id), open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        String title, text;
        if (possibleDup) {
            title = "Possible duplicate — " + rupees(amount) + " · " + what;
            text = "Not saved yet. Tap to review.";
        } else {
            title = rupees(amount) + " saved · " + what;
            text = "Tap to view or edit. Wrong? Tap Delete.";
        }

        Notification.Builder b = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(0xFF3B4CC0)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pOpen);

        if (!possibleDup) {
            Intent del = new Intent(c, ActionReceiver.class)
                    .setAction(ActionReceiver.ACTION_DELETE)
                    .putExtra("id", id);
            PendingIntent pDel = PendingIntent.getBroadcast(c, notifId(id) + 1, del,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            b.addAction(new Notification.Action.Builder((Icon) null, "Delete", pDel).build());
        }
        nm.notify(notifId(id), b.build());
    }
}
