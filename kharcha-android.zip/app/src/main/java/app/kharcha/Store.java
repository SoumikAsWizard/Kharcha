package app.kharcha;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Small native store. Incoming SMS wait in "pending" until the app opens and merges them
 * into the main records (kept by the web part). "deleted" holds ids removed from a notification
 * after they were already merged. "index" is a copy of recent expenses for duplicate checks.
 */
final class Store {
    private static final String PREFS = "kharcha";

    private Store() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static JSONArray read(Context c, String key) {
        try {
            return new JSONArray(prefs(c).getString(key, "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    private static void write(Context c, String key, JSONArray a) {
        prefs(c).edit().putString(key, a.toString()).commit();
    }

    private static Set<String> idSet(String json) {
        Set<String> s = new HashSet<>();
        try {
            JSONArray a = new JSONArray(json);
            for (int i = 0; i < a.length(); i++) s.add(a.optString(i));
        } catch (JSONException ignored) { }
        return s;
    }

    static String isoDate(long ts) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(ts));
    }

    // ----- pending -----
    static synchronized void addPending(Context c, String id, String body, long ts, String from,
                                        double amount, String date, boolean emi) {
        JSONArray a = read(c, "pending");
        JSONObject o = new JSONObject();
        try {
            o.put("id", id).put("body", body).put("ts", ts).put("from", from)
             .put("amount", amount).put("date", date).put("emi", emi);
        } catch (JSONException ignored) { }
        a.put(o);
        write(c, "pending", a);
    }

    static synchronized String getPending(Context c) {
        return read(c, "pending").toString();
    }

    static synchronized void ackPending(Context c, String idsJson) {
        Set<String> ids = idSet(idsJson);
        JSONArray a = read(c, "pending"), out = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && !ids.contains(o.optString("id"))) out.put(o);
        }
        write(c, "pending", out);
    }

    static synchronized boolean hasPending(Context c, String id) {
        JSONArray a = read(c, "pending");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) return true;
        }
        return false;
    }

    // ----- SMS reading on/off -----
    static boolean smsOn(Context c) {
        return prefs(c).getBoolean("sms_on", true);
    }

    static void setSmsOn(Context c, boolean on) {
        prefs(c).edit().putBoolean("sms_on", on).commit();
    }

    /** @return true if the item was still waiting (so it never reaches the records). */
    static synchronized boolean removePending(Context c, String id) {
        JSONArray a = read(c, "pending"), out = new JSONArray();
        boolean found = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (id.equals(o.optString("id"))) found = true; else out.put(o);
        }
        if (found) write(c, "pending", out);
        return found;
    }

    // ----- deleted -----
    static synchronized void addDeleted(Context c, String id) {
        JSONArray a = read(c, "deleted");
        a.put(id);
        write(c, "deleted", a);
    }

    static synchronized String getDeleted(Context c) {
        return read(c, "deleted").toString();
    }

    static synchronized void ackDeleted(Context c, String idsJson) {
        Set<String> ids = idSet(idsJson);
        JSONArray a = read(c, "deleted"), out = new JSONArray();
        for (int i = 0; i < a.length(); i++) if (!ids.contains(a.optString(i))) out.put(a.optString(i));
        write(c, "deleted", out);
    }

    // ----- duplicate index -----
    static synchronized void setIndex(Context c, String json) {
        prefs(c).edit().putString("index", json).apply();
    }

    private static boolean same(double a, double b, String d1, String d2, boolean emi1, boolean emi2) {
        boolean emi = emi1 && emi2;
        if (Math.abs(a - b) >= (emi ? 1.01 : 0.01)) return false;
        if (d1.equals(d2)) return true;
        return emi && d1.length() >= 7 && d2.length() >= 7 && d1.substring(0, 7).equals(d2.substring(0, 7));
    }

    static synchronized boolean isLikelyDup(Context c, double amount, String date, boolean emi) {
        JSONArray idx = read(c, "index");
        for (int i = 0; i < idx.length(); i++) {
            JSONObject o = idx.optJSONObject(i);
            if (o != null && same(amount, o.optDouble("a", -1), date, o.optString("d", ""), emi, o.optBoolean("e", false))) return true;
        }
        JSONArray p = read(c, "pending");
        for (int i = 0; i < p.length(); i++) {
            JSONObject o = p.optJSONObject(i);
            if (o != null && same(amount, o.optDouble("amount", -1), date, o.optString("date", ""), emi, o.optBoolean("emi", false))) return true;
        }
        return false;
    }
}
