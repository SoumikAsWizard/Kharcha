package app.kharcha;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import java.util.LinkedHashMap;
import java.util.Map;

/** Runs for every incoming SMS, even when Kharcha is closed. */
public class SmsReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        if (!Store.smsOn(context)) return;
        SmsMessage[] parts = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (parts == null) return;

        // Long messages arrive in parts: join them per sender.
        Map<String, StringBuilder> bodies = new LinkedHashMap<>();
        long ts = System.currentTimeMillis();
        for (SmsMessage m : parts) {
            if (m == null) continue;
            String from = m.getDisplayOriginatingAddress();
            if (from == null) from = "";
            StringBuilder sb = bodies.get(from);
            if (sb == null) { sb = new StringBuilder(); bodies.put(from, sb); }
            String body = m.getMessageBody();
            if (body != null) sb.append(body);
            ts = m.getTimestampMillis();
        }

        for (Map.Entry<String, StringBuilder> e : bodies.entrySet()) {
            String from = e.getKey();
            String body = e.getValue().toString();
            if (!Filter.isBankSender(from) || !Filter.isDebit(body)) continue;

            double amount = Filter.amount(body);
            String date = Store.isoDate(ts);
            boolean emi = Filter.isEmi(body);
            boolean dup = Store.isLikelyDup(context, amount, date, emi);
            String id = "n" + Long.toString(ts, 36) + Integer.toString((int) (Math.random() * 1_000_000), 36);

            Store.addPending(context, id, body, ts, from, amount, date, emi);
            Notifier.saved(context, id, amount, Filter.merchant(body), dup);
        }
    }
}
