package app.kharcha;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Quick checks used before the full JavaScript parser runs inside the app. */
final class Filter {
    private static final int CI = Pattern.CASE_INSENSITIVE;
    private static final String CUR = "(?:rs\\.?:?|inr|₹)";
    private static final String NUM = "([\\d,]+(?:\\.\\d{1,2})?)";

    private static final Pattern OTP = Pattern.compile("\\b(otp|one[\\s-]time\\s+password|verification code)\\b", CI);
    private static final Pattern DEBIT = Pattern.compile("\\b(debited|deducted|spent|withdrawn|paid|sent|charged|debit|purchase|auto[\\s-]?debit|for\\s+using\\s+your)\\b", CI);
    private static final Pattern REMIND = Pattern.compile("\\b(will be|is due|due on|due date|scheduled|upcoming|reminder|collect request)\\b", CI);
    private static final Pattern DONE = Pattern.compile("\\b(has been|have been|was|is)\\s+(debited|deducted)", CI);
    private static final Pattern EMI = Pattern.compile("\\b(emi|loan|ecs|nach|mandate|auto[\\s-]?debit|standing instruction)\\b", CI);
    private static final Pattern PHONE = Pattern.compile("^\\+?\\d{7,}$");

    private static final Pattern[] AMOUNTS = {
        Pattern.compile("(?:debited|deducted|spent|paid|withdrawn|sent|charged|txn|transaction|purchase|payment)[^0-9₹]{0,25}?" + CUR + "\\s*" + NUM, CI),
        Pattern.compile(CUR + "\\s*" + NUM + "[^.]{0,40}?(?:debited|deducted|spent|paid|withdrawn|sent|charged)", CI),
        Pattern.compile("debited\\s+(?:by|for|with)\\s+" + NUM, CI),
        Pattern.compile(CUR + "\\s*" + NUM, CI),
    };
    private static final Pattern[] MERCHANTS = {
        Pattern.compile("\\bto\\s+vpa\\s+([\\w.\\-]+@\\w+)", CI),
        Pattern.compile("\\b(?:to|at)\\s+([A-Za-z0-9@._&'\\- ]{2,30}?)(?=\\s+(?:on|ref|refno|upi|via|avl|txn|using)\\b|[.,;\\n]|$)", CI),
        Pattern.compile(";\\s*([A-Z][A-Za-z0-9 .&'\\-]{1,30}?)\\s+credited"),
        Pattern.compile("([\\w.\\-]+@[a-z]+)\\b", CI),
    };

    private Filter() {}

    /** Bank and UPI alerts come from letter codes like "JD-HDFCBK-S", not phone numbers. "-P" = promotional. */
    static boolean isBankSender(String address) {
        if (address == null) return false;
        String a = address.trim();
        if (a.isEmpty() || PHONE.matcher(a).matches()) return false;
        return !a.toUpperCase().endsWith("-P");
    }

    static boolean isDebit(String body) {
        if (body == null) return false;
        if (OTP.matcher(body).find()) return false;
        if (!DEBIT.matcher(body).find()) return false;
        if (REMIND.matcher(body).find() && !DONE.matcher(body).find()) return false;
        return amount(body) > 0;
    }

    static boolean isEmi(String body) {
        return body != null && EMI.matcher(body).find();
    }

    static double amount(String body) {
        if (body == null) return 0;
        for (Pattern p : AMOUNTS) {
            Matcher m = p.matcher(body);
            if (m.find()) {
                try {
                    double v = Double.parseDouble(m.group(1).replace(",", ""));
                    if (v > 0) return v;
                } catch (NumberFormatException ignored) { }
            }
        }
        return 0;
    }

    static String merchant(String body) {
        if (body == null) return "";
        for (Pattern p : MERCHANTS) {
            Matcher m = p.matcher(body);
            if (m.find()) {
                String v = m.group(1).trim().replaceAll("\\s{2,}", " ");
                if (v.length() >= 2 && !v.matches("(?i)^(your|you|a/c|ac|account|card|rs|inr|the)\\b.*")) return v;
            }
        }
        return "";
    }
}
