package app.kharcha;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/** Handles the "Delete" button on a "saved" notification. */
public class ActionReceiver extends BroadcastReceiver {
    static final String ACTION_DELETE = "app.kharcha.DELETE";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!ACTION_DELETE.equals(intent.getAction())) return;
        String id = intent.getStringExtra("id");
        if (id == null) return;
        // Not merged yet: drop it from the queue. Already merged: tell the app to remove it.
        if (!Store.removePending(context, id)) Store.addDeleted(context, id);
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(Notifier.notifId(id));
        Toast.makeText(context, "Deleted from Kharcha", Toast.LENGTH_SHORT).show();
    }
}
