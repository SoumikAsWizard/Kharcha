package app.kharcha;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 1;
    private static final int REQ_FILE = 42;
    private static final String HOME = "file:///android_asset/index.html";

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private boolean pageReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF3B4CC0);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT)
                        .addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(pick, "Choose backup file"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl(HOME + queryFor(getIntent()));

        if (savedInstanceState == null && !hasNotif()) requestPerms();
        GmailJob.schedule(this);
    }

    private static String enc(String v) {
        try {
            return URLEncoder.encode(v, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private String queryFor(Intent i) {
        if (i == null) return "";
        String edit = i.getStringExtra("edit");
        if (edit != null) return "?edit=" + enc(edit);
        if (Intent.ACTION_SEND.equals(i.getAction())) {
            String t = i.getStringExtra(Intent.EXTRA_TEXT);
            if (t != null) return "?text=" + enc(t);
        }
        return "";
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        JSONObject o = new JSONObject();
        try {
            String edit = intent.getStringExtra("edit");
            if (edit != null) o.put("edit", edit);
            if (Intent.ACTION_SEND.equals(intent.getAction())) {
                String t = intent.getStringExtra(Intent.EXTRA_TEXT);
                if (t != null) o.put("text", t);
            }
        } catch (JSONException ignored) { }
        js("window.kharchaNativeEvent && window.kharchaNativeEvent(" + o + ")");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pageReady) js("window.kharchaResume && window.kharchaResume()");
    }

    private void js(String code) {
        if (web != null) web.post(() -> web.evaluateJavascript(code, null));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        js("window.kharchaPerm && window.kharchaPerm()");
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private boolean granted(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    // SMS reading was removed: Play Protect blocks sideloaded apps that ask for SMS access.
    private boolean hasSms() {
        return false;
    }

    private boolean hasNotif() {
        return Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS);
    }

    private void requestPerms() {
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS))
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    private Uri writeDownload(String name, String mime, String text) throws Exception {
        ContentResolver r = getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Kharcha");
        Uri uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new IllegalStateException("insert failed");
        try (OutputStream out = r.openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("no stream");
            out.write(text.getBytes(StandardCharsets.UTF_8));
        }
        return uri;
    }

    /** Methods callable from the page as window.Android.* */
    private class Bridge {
        @JavascriptInterface public String getPending() { return Store.getPending(MainActivity.this); }
        @JavascriptInterface public void ackPending(String ids) { Store.ackPending(MainActivity.this, ids); }
        @JavascriptInterface public String getDeleted() { return Store.getDeleted(MainActivity.this); }
        @JavascriptInterface public void ackDeleted(String ids) { Store.ackDeleted(MainActivity.this, ids); }
        @JavascriptInterface public void syncIndex(String json) { Store.setIndex(MainActivity.this, json); }
        @JavascriptInterface public boolean hasSms() { return MainActivity.this.hasSms(); }
        @JavascriptInterface public boolean smsOn() { return Store.smsOn(MainActivity.this); }
        @JavascriptInterface public void setSmsOn(boolean on) { Store.setSmsOn(MainActivity.this, on); }

        // ----- Gmail -----
        @JavascriptInterface public void gmailConfig(String url, String key) {
            Gmail.setConfig(MainActivity.this, url, key);
            GmailJob.schedule(MainActivity.this);
        }
        @JavascriptInterface public void gmailClear() {
            Gmail.clear(MainActivity.this);
            GmailJob.cancel(MainActivity.this);
        }
        @JavascriptInterface public String gmailStatus() { return Gmail.status(MainActivity.this); }
        /** Runs in the background; calls window.kharchaGmailDone(status) when finished. */
        @JavascriptInterface public void gmailSyncNow() {
            new Thread(() -> {
                Gmail.syncToPending(MainActivity.this);
                js("window.kharchaGmailDone && window.kharchaGmailDone(" + Gmail.status(MainActivity.this) + ")");
            }).start();
        }
        /** Past emails for review; calls window.kharchaGmailImport(json) when finished. */
        @JavascriptInterface public void gmailFetch(String sinceMs) {
            new Thread(() -> {
                String out;
                try {
                    out = "{\"items\":" + Gmail.fetch(MainActivity.this, Long.parseLong(sinceMs)) + "}";
                } catch (Exception e) {
                    out = "{\"error\":" + JSONObject.quote(String.valueOf(e.getMessage())) + "}";
                }
                js("window.kharchaGmailImport && window.kharchaGmailImport(" + out + ")");
            }).start();
        }
        @JavascriptInterface public boolean hasNotif() { return MainActivity.this.hasNotif(); }
        @JavascriptInterface public void requestPerms() { runOnUiThread(MainActivity.this::requestPerms); }

        @JavascriptInterface public void openAppSettings() {
            runOnUiThread(() -> {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null));
                startActivity(i);
            });
        }

        @JavascriptInterface public String saveFile(String name, String mime, String text) {
            try {
                writeDownload(name, mime, text);
                return "Saved to Downloads/Kharcha";
            } catch (Exception e) {
                return "Couldn't save the file";
            }
        }

        @JavascriptInterface public String shareFile(String name, String mime, String text) {
            try {
                Uri uri = writeDownload(name, mime, text);
                Intent send = new Intent(Intent.ACTION_SEND)
                        .setType(mime)
                        .putExtra(Intent.EXTRA_STREAM, uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(() -> startActivity(Intent.createChooser(send, "Save backup to…")));
                return "Saved to Downloads/Kharcha";
            } catch (Exception e) {
                return "Couldn't save the file";
            }
        }

    }
}
