package app.kharcha;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Talks to the user's own Google Apps Script, which returns bank alert emails (read-only). */
final class Gmail {
    private static final String PREFS = "kharcha_gmail";

    private Gmail() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean configured(Context c) {
        SharedPreferences p = prefs(c);
        return !p.getString("url", "").isEmpty() && !p.getString("key", "").isEmpty();
    }

    static void setConfig(Context c, String url, String key) {
        SharedPreferences.Editor e = prefs(c).edit()
                .putString("url", url == null ? "" : url.trim())
                .putString("key", key == null ? "" : key.trim())
                .putString("error", "");
        if (prefs(c).getLong("last", 0) == 0) e.putLong("last", System.currentTimeMillis() - 2 * 86_400_000L);
        e.commit();
    }

    static void clear(Context c) {
        prefs(c).edit().clear().commit();
    }

    static String status(Context c) {
        SharedPreferences p = prefs(c);
        JSONObject o = new JSONObject();
        try {
            o.put("configured", configured(c))
             .put("checked", p.getLong("checked", 0))
             .put("added", p.getInt("added", 0))
             .put("error", p.getString("error", ""));
        } catch (JSONException ignored) { }
        return o.toString();
    }

    private static String get(String address) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(address).openConnection();
        con.setInstanceFollowRedirects(true);
        con.setConnectTimeout(20_000);
        con.setReadTimeout(90_000);
        int code = con.getResponseCode();
        // Apps Script answers with a redirect to googleusercontent.com.
        int hops = 0;
        while ((code == 301 || code == 302 || code == 303 || code == 307) && hops++ < 5) {
            String next = con.getHeaderField("Location");
            con.disconnect();
            con = (HttpURLConnection) new URL(next).openConnection();
            con.setConnectTimeout(20_000);
            con.setReadTimeout(90_000);
            code = con.getResponseCode();
        }
        if (code != 200) throw new IllegalStateException("HTTP " + code);
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
        } finally {
            con.disconnect();
        }
        return sb.toString();
    }

    /** All alert emails newer than {@code since} (ms), oldest first. */
    static JSONArray fetch(Context c, long since) throws Exception {
        SharedPreferences p = prefs(c);
        String url = p.getString("url", ""), key = p.getString("key", "");
        if (url.isEmpty() || key.isEmpty()) throw new IllegalStateException("Gmail not set up");
        JSONArray all = new JSONArray();
        long s = since;
        for (int page = 0; page < 10; page++) {
            String address = url + (url.contains("?") ? "&" : "?")
                    + "key=" + URLEncoder.encode(key, "UTF-8") + "&since=" + s;
            JSONObject res = new JSONObject(get(address));
            String err = res.optString("error", "");
            if (!err.isEmpty()) throw new IllegalStateException(err);
            JSONArray items = res.optJSONArray("items");
            if (items == null || items.length() == 0) break;
            for (int i = 0; i < items.length(); i++) all.put(items.optJSONObject(i));
            s = items.optJSONObject(items.length() - 1).optLong("ts", s);
            if (!res.optBoolean("more", false)) break;
        }
        return all;
    }

    /** Background sync: queue new debit emails for the app and show a notification for each. */
    static synchronized int syncToPending(Context c) {
        SharedPreferences p = prefs(c);
        if (!configured(c)) return 0;
        int added = 0;
        try {
            long last = p.getLong("last", System.currentTimeMillis() - 2 * 86_400_000L);
            JSONArray items = fetch(c, last);
            long newest = last;
            for (int i = 0; i < items.length(); i++) {
                JSONObject it = items.optJSONObject(i);
                if (it == null) continue;
                String id = it.optString("id", ""), body = it.optString("body", "");
                long ts = it.optLong("ts", 0);
                newest = Math.max(newest, ts);
                if (id.isEmpty() || Store.hasPending(c, id) || !Filter.isDebit(body)) continue;
                double amount = Filter.amount(body);
                String date = Store.isoDate(ts);
                boolean emi = Filter.isEmi(body);
                boolean dup = Store.isLikelyDup(c, amount, date, emi);
                Store.addPending(c, id, body, ts, "gmail", amount, date, emi);
                Notifier.saved(c, id, amount, Filter.merchant(body), dup);
                added++;
            }
            p.edit().putLong("last", newest).putLong("checked", System.currentTimeMillis())
                    .putInt("added", added).putString("error", "").commit();
        } catch (Exception e) {
            p.edit().putLong("checked", System.currentTimeMillis())
                    .putString("error", e.getMessage() == null ? "Couldn't reach Gmail" : e.getMessage()).commit();
        }
        return added;
    }
}
